---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
description: ""
date: {{ .Date }}
lastmod: {{ .Date }}
cover: ""
coverAlt: ""
toc: false
tags: []
draft: true
---