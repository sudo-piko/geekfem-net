---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
description: ""
date: {{ .Date }}
katex: true
katexExtensions: [ mhchem, copy-tex ]
draft: true
---