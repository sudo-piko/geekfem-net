---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
description: ""
date: {{ .Date }}
cover: ""
coverAlt: ""
sitemapExclude: true
noindex: true
disableTitleSeparator: false
draft: true
---